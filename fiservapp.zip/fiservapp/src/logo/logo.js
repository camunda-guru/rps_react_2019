//stateless compoenent using functional way
import React from 'react'
import logoPath from '../assets/images/amazon.jpg'
import  './logo.css'
const logo=()=>(
<img src={logoPath} alt="ecommerce site"
     className="logoStyle"/>
);

export default logo;