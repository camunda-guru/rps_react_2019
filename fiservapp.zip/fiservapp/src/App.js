import React, { Component } from 'react';
//import logo from './logo.svg';
import './App.css';
import Logo from './logo/logo'
import Menu from './menu/menu'
import 'bootstrap/dist/css/bootstrap.min.css';
class App extends Component {

    state={
      menuItems:[
          {
              id:1,
              name:"Solutions",
              icon:"add"

          },
          {
              id:2,
              name:"Industries",
              icon:"office"

          },
          {
              id:3,
              name:"About",
              icon:"person"

          },
          {
              id:4,
              name:"Careers",
              icon:"job"

          }
      ]

    };



   constructor()
   {
       super();
       console.log("App Constructor is called");
   }

   componentWillMount()
   {
       console.log("App enters will Mount");
   }
    componentDidMount()
    {
        console.log("App enters did Mount");
    }
    render() {
       console.log("App enters render");
    return (
      <div className="container">
         <Logo/>
          <Menu elements={this.state.menuItems}/>
      </div>
    );
  }
}

export default App;
