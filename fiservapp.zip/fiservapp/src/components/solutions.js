import React,{Component} from 'react'


export class Solutions extends Component
{


    render(){

        return(
            <h1>Loading Solutions.....</h1>
        )

    }



}