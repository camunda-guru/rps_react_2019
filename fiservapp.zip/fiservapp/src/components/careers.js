import React,{Component} from 'react'


export class Careers extends Component
{


    render(){

        return(
            <h1>Loading Careers.....</h1>
        )

    }



}