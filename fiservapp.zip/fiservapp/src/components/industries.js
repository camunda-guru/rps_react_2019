import React,{Component} from 'react'


export class Industries extends Component
{


    render(){

        return(
            <h1>Loading Industries.....</h1>
        )

    }



}