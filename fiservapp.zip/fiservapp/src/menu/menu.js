import React from 'react'
import './menu.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import {HashRouter as Router, Link,Switch,Route} from 'react-router-dom'
import {Solutions} from "../components/solutions";
import {Industries} from "../components/industries";
import {About} from "../components/about";
import {Careers} from "../components/careers";

const menu=(props)=>(
    <Router>
    <nav className="navbar navbar-expand-lg navbar-light bg-light ">
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
    <ul className="navbar-nav mr-auto">
        {

            props.elements.map(element=>(

                <li key={element.id} className="liStyle">
                    <Link to={element.name}>{element.name}</Link>
                    </li>

            ))
        }

    </ul>
     <Switch>
     <Route path='/Solutions' component={Solutions}/>
         <Route path='/Industries' component={Industries}/>
         <Route path='/About' component={About}/>
         <Route path='/Careers' component={Careers}/>
     </Switch>


        </div>
    </nav>
    </Router>
);

export default menu;