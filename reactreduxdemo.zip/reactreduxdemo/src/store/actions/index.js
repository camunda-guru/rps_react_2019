import uuidv4 from 'uuid/v4';
import { ADD_POST, REMOVE_POST } from './actions';

export const createPost = ({ title, body }) => ({
    type: ADD_POST,
    payload: {
        id: uuidv4(),
        title,
        body
    }
});

export const deletePost = id => ({
    type: REMOVE_POST,
    payload: {
        id
    }
});