import React from 'react'
import classes from  './DaimlerMenu.css'
import {BrowserRouter as Router,Link,Switch,Route} from 'react-router-dom'
import {Dashboard} from '../Dashboard/Dashboard'
import {NewRequest} from '../NewRequest/NewRequest'
import {Layout} from "../Layout/Layout";
import Admin from '../Admin/Admin'
import Aboutus from '../Aboutus/Aboutus'
const daimlerMenu=(props)=>(
<Router>
    <nav className={classes.navigation}>
    <ul>
        {
            /*<li className="DaimlerMenu"><a href="#">Home</a></li>*/

          props.items.map(item=>(

              <li key={item.id} className={classes.DaimlerMenu}>
                  <Link to={item.name}>{item.name}</Link>
                  </li>

          ))

        }
    </ul>
    <Switch>
       <Route path='/Dashboard' component={Dashboard} >

    </Route>
        <Route path='/NewRequest' component={Layout} >

        </Route>
        <Route path='/Admin' component={Admin} >

        </Route>
        <Route path='/Aboutus' component={Aboutus} >

        </Route>
    </Switch>
    </nav>
</Router>
);

export default daimlerMenu


